# Slime Entourage

This is a resource pack that makes small slimes shout that the player is "the greatest redstone master in the world"
in the (pitch-shifted) voice of [EthosLab](https://www.youtube.com/channel/UCFKDEp9si4RmHFWJW1vYsMA).

It was generated explicitly for [Tango Tek](https://www.youtube.com/@TangoTekLP) in response to his video:
[I'm a Corporate Sellout! - Hermitcraft 10 # 11](https://www.youtube.com/watch?v=oAvPZwbM1Mc&t=586s).

## Credits

The author of this resource pack claims no rights to any of the underlying assets.

- The voice of the slimes is provided by [EthosLab](https://www.youtube.com/channel/UCFKDEp9si4RmHFWJW1vYsMA)
- as recorded by [BDoubleO100](https://www.youtube.com/@bdoubleo).
- The pack icon is taken from the thumbnail of [Tango's video](https://www.youtube.com/watch?v=oAvPZwbM1Mc).

The combining of these elements into this resource pack was done under the principle of fair use.

## License

This pack and its contents has been marked as dedicated to the public domain. Details can be found in
the accompanying LICENSE.txt file.

